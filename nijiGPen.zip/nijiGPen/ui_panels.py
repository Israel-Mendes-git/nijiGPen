import bpy
from ..api_router import *

class RenderAndVectorizeMenu(bpy.types.Menu):
    bl_label = "Render and Convert Scene/Mesh"
    bl_idname = "NIJIGP_MT_render_and_vectorize"
    def draw(self, context):
        self.layout.operator("gpencil.nijigp_render_and_vectorize")

# Panels that appear in more than one mode
def panel_global_setting(panel, context):
    layout = panel.layout
    scene = context.scene
    row = layout.row()
    row.label(text="Working Plane:")
    row.prop(scene, "nijigp_working_plane", text='')
    if scene.nijigp_working_plane == 'VIEW' or scene.nijigp_working_plane == 'AUTO':
        row = layout.row()
        row.prop(scene, "nijigp_working_plane_layer_transform", text='Use Transform of Active Layer')

def panel_io(panel, context):
    layout = panel.layout

    layout.label(text="Paste from Clipboard:")
    row = layout.row()
    row.operator("gpencil.nijigp_paste_svg", text="SVG Code", icon="PASTEDOWN")
    row.operator("gpencil.nijigp_paste_swatch", text="Swatches", icon="PASTEDOWN")

    layout.label(text="Image Vectorization:")
    row = layout.split()
    row.operator("gpencil.nijigp_import_lineart", text="Line Art", icon="LINE_DATA")
    sub_row = row.row(align=True)
    sub_row.operator("gpencil.nijigp_import_color_image", text="Flat Color", icon="IMAGE")
    sub_row.menu("NIJIGP_MT_render_and_vectorize", text="", icon="TRIA_DOWN")

    layout.label(text="Asset Import:")
    row = layout.row()
    row.operator("gpencil.nijigp_import_brush", text="Brushes", icon="BRUSH_DATA")
    row.operator("gpencil.nijigp_import_swatch", text="Swatches", icon="COLOR")
    row = layout.row()
    row.operator("gpencil.nijigp_append_svg", text="Append SVG", icon="FILE_TICK")
    
    layout.label(text="Image Export:")
    row = layout.row()
    row.operator("gpencil.nijigp_multilayer_render", text="Multi-Layer PSD Render", icon="RENDERLAYERS")


     
class NIJIGP_PT_draw_panel_line(bpy.types.Panel):
    bl_idname = 'NIJIGP_PT_draw_panel_line'
    bl_label = "Line Operators"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "NijiGP"
    bl_context = get_bl_context_str('paint')
    bl_order = 1

    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator("gpencil.nijigp_fit_last", icon='MOD_SMOOTH')
        row = layout.row()
        row.operator("gpencil.nijigp_smart_fill", icon='SHADING_SOLID')


